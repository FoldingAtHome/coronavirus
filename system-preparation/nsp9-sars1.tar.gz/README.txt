1. Took 1qz8
2. Added N-terminal coordinates from NSP9-SARS2
