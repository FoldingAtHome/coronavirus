1. Download swiss model 01: https://swissmodel.expasy.org/interactive/GqQg8A/models/01
2. use pymol to add on NN and NNE to chains A and B respectively (missing in model)
